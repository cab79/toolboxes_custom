function Error_Message(Error)
if(Error ~= 0)
    ErrorString = ljud_ErrorToString(Error)
end
