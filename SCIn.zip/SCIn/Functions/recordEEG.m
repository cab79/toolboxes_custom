function h = recordEEG(h,opt)
global dio

switch opt
    case 'connect'
        try
            if strcmp(h.Settings.record_EEG,'NS')
                %% ---------------- CONNECT TO NETSTATION ------------------%
                nshost = '10.0.0.42';
                nsport = 55513;

                if ~isfield(h,'NS')
                    h.NS=struc;
                end

                if ~isfield(h.NS,'status') && ...
                        exist('nshost','var') && ~isempty(nshost) && ...
                        exist('nsport','var') && nsport ~= 0
                    fprintf('Connecting to Net Station.\n');
                    [h.NS.status, nserror] = NetStation('Connect',nshost,nsport);
                    if h.NS.status ~= 0
                        error('Could not connect to NetStation host %s:%d.\n%s\n', ...
                            nshost, nsport, nserror);
                    end
                end
                NetStation('Synchronize');
            elseif strcmp(h.Settings.record_EEG,'BV')
                %% ---------------- CONNECT TO BRAINVISION ------------------%
                if ~isfield(h,'BV'); 
                    h.BV.delay = 0.001;
                end
                h.BV.status = 0;
            elseif strcmp(h.Settings.record_EEG,'labjack_DB15')
                if ~isfield(h,'ljHandle')
                   error('first connect labjack for EEG markers') 
                end
                
                %% ---------------- CONNECT TO BRAINVISION ------------------%
                if ~isfield(h,'BV'); 
                    h.BV.delay = 0.002;
                end
                h.BV.status = 0;
                
            elseif strcmp(h.Settings.record_EEG,'serial')
                opt = 'spt1';
                open_serial(h,opt);
            elseif strcmp(h.Settings.record_EEG,'daq')
                %% Using Data Acquisition Toolbox to write 8 lines of digital output data
                % to a National Instruments NI-USB-6501 device
                dio = daq.createSession('ni');
                h.dioch = addDigitalChannel(dio,'Dev1','Port0/Line0:7','OutputOnly');
                %dio=digitalio('nidaq', 'Dev1'); % create digital IO object
                %addline(dio, 0:7, 'out'); % add 24 lines representing the 3 ports of 8 lines each
                %h.lineconfig=dio.Line % display index and digital line configurations to show mapping
            end
            
            
            questdlg('Using EEG: Please start the recording now', ...
                    'Choice', ...
                    'EEG started','Not recording EEG','EEG started');
            
%             choice = questdlg('Using EEG: Disable GUI buttons? (more accurate EEG markers)', ...
%                     'Choice', ...
%                     'Yes','No','Yes');
%             switch choice
%                 case 'Yes'
%                     h.disableGUI=1;
%             end
        catch MExc
            choice = questdlg('EEG not connected. Stop or continue?', ...
                    'Choice', ...
                    'Stop','Continue','Continue');
            switch choice
                case 'Stop'
                    error('Experiment stopped')
            end
        end
    case 'start'
        %% NS: start recording
        try
            if strcmp(h.Settings.record_EEG,'NS')
                Priority(2);
                NetStation('StartRecording');
                pause(5)
                NetStation('Synchronize');
                NetStation('Event','BGIN');
                pause(1);
            elseif strcmp(h.Settings.record_EEG,'BV')
                % do nothing
            end
        catch
            choice = questdlg('EEG not started. Stop or continue?', ...
                    'Choice', ...
                    'Stop','Continue','Continue');
            switch choice
                case 'Stop'
                    error('Experiment stopped')
            end
        end
    case 'pause'
        NetStation('Event','PAUS'); % mark EEG
        pause(1)
    case 'resume'
        NetStation('Event','CONT'); % mark EEG
        pause(1)
    case 'stop'
        %% ---------------- STOP RECORDING ------------------%
        try
            if strcmp(h.Settings.record_EEG,'NS')
                pause(1);
                NetStation('Event','STOP');
                pause(5);
                Priority(0);
                NetStation('StopRecording');
            elseif strcmp(h.Settings.record_EEG,'BV')
                % nothing
            end
        catch
            msgbox('EEG is still recording','Message');
        end
    case 'mark'
        if strcmp(h.Settings.record_EEG,'NS')
            NetStation('Event','STIM',stimtime,0.001,'TNUM',ns,'CNUM',h.Seq.condnum(h.i),'FNUM',h.Seq.signal(h.i),'BNUM',h.Seq.block(h.i));
            
        elseif strcmp(h.Settings.record_EEG,'BV')
            %--- EEG trigger on, via Labjack USB - for Brainamps ---%
            Error = ljud_AddRequest(h.ljHandle,LJ_ioPUT_DIGITAL_BIT,5,1,0,0);
            Error_Message(Error)

            % wait for a short delay
            Error = ljud_AddRequest(h.ljHandle,LJ_ioPUT_WAIT,5,h.BV.delay*1000000,0,0);
            Error_Message(Error)

            %--- EEG trigger off, via Labjack USB - for Brainamps ---%
            Error = ljud_AddRequest(h.ljHandle,LJ_ioPUT_DIGITAL_BIT,5,0,0,0);
            Error_Message(Error)

            % send command
            Error = ljud_GoOne(h.ljHandle);
            Error_Message(Error)
         elseif strcmp(h.Settings.record_EEG,'labjack_DB15')
                TriggerNum = h.Seq.condnum(h.i);
             
            if isunix
                h.ljHandle.setDIOValue(TriggerNum);
                WaitSecs(h.BV.delay);
                h.ljHandle.setDIOValue(0);
                
            else
                ljud_LoadDriver; % Loads LabJack UD Function Library
                ljud_Constants; % Loads LabJack UD constant file

                %--- EEG trigger on, via Labjack USB ---%
                Error = ljud_AddRequest(h.ljHandle,LJ_ioPUT_DIGITAL_PORT, 8, TriggerNum, 8, 0);
                %Error = ljud_AddRequest(h.ljHandle,LJ_ioPUT_DIGITAL_BIT, 8, 1, 0, 0);
                Error_Message(Error)
                % wait for a short delay
                Error = ljud_AddRequest(h.ljHandle,LJ_ioPUT_WAIT,8,h.BV.delay*1000000,0,0);
                Error_Message(Error)
                %--- EEG trigger off, via Labjack USB---%
                Error = ljud_AddRequest(h.ljHandle,LJ_ioPUT_DIGITAL_PORT, 8, 0, 8, 0);
                %Error = ljud_AddRequest(h.ljHandle,LJ_ioPUT_DIGITAL_BIT, 8, 0, 0, 0);
                Error_Message(Error)
                % send command
                Error = ljud_GoOne(h.ljHandle);
                Error_Message(Error)
            end
            
        elseif strcmp(h.Settings.record_EEG,'serial')
            try
                global spt1
                TriggerNum = h.Seq.signal(h.i);
                fprintf(spt1,num2str(32+TriggerNum));
            catch
                disp('EEG not connected');
            end
        elseif strcmp(h.Settings.record_EEG,'daq')
            try
                TriggerNum = 0;
                outputSingleScan(dio,flip(decimalToBinaryVector(TriggerNum,8)))
                TriggerNum = h.Seq.signal(h.i);
                outputSingleScan(dio,flip(decimalToBinaryVector(TriggerNum,8)))
                %putvalue(dio.Line(1:8),TriggerNum); 
            catch
                disp('EEG not connected');
            end
        end
end