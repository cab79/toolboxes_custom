out.presstrial(strcmp(out.pressbutton,'7&'))
find(strcmp(out.firstpressbutton,'7&'))
out.firstpress
out.lastpress